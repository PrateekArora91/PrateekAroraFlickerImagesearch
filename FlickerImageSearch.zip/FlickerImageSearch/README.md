# FlickerImageSearch
Flicker image is a single page application written in swift. The application searches for images using Flickr API which will get displayed in 3 * N Colums. The images are displayed in a paginated way. The application is designed using MVVM architecture.


##  Flickr API

Search results are reterived using [Flickr API] 
Url : https://api.flickr.com/services/rest/
Query Param:  
{
"method" : "flickr.photos.search"
"api_key" : ""
"format" : "json"
"nojsoncallback" : 1,
"safe_search" : 1
"per_page" : 10
"text" : "searchText"
"page" : 1
}

**Search Path**: https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key={fickr_api_key}&format=json&nojsoncallback=1&safe_search=1&per_page={page_size}&text={search_text}&page={page_num}
**Example**: https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=a4f28588b57387edc18282228da39744&format=json&nojsoncallback=1&safe_search=1&per_page=10&text=dog&page=1
- Response includes an array of photo objects, each represented as:
``` swift
{
"id": "50146847593",
"owner": "142798405@N04",
"secret": "0877f34584",
"server": "65535",
"farm": 66,
"title": "Strolling the dog",
"ispublic": 1,
"isfriend": 0,
"isfamily": 0
},
```
**Image Path**
 http://farm{farm}.static.flickr.com/{server}/{id}_{secret}.jpg

## Class defination 
### FlickerImageSearch
1.The module consist of all related to flicker image search using UICollectionView with Pagination 
2.The application also shows the cool feature like endless scroll and automatically load of next page when the user reaches to end of current page.
3.The application supports both landscape and potrait mode which is achieved with the help of autolayout.


### Views
**ViewControllers** : The view controller module consist of **FlickerCollectionViewController** which consists of collection view and text fields with following features given below:
1) Fetching
2) Refreshing
3) Searching
**ImageCollectionViewCell** : The cell is been reused for displaying content fetched from service, where content is downloaded asyncronously using **ImageDownloadManager** 

#### ViewModels
- **FlickerViewModel**: This class represents data to be rendered in **FlickerCollectionViewController** 
- **ImageModel**: ImageModel represents data to be rendered in collection view cells.

#### Models
- **FlickrSearchResults**: This class involved for searching result using codable protocol for parsing.
- **FlickerPhoto**: This class is involved for pagination detailsand array if images from **FlickerSearchResults**.
- **Photos**: This class reperesnts data structure for image details.

#### Services
- **FlickrSearchService**: This class is responsible for parsing following things with the help of **NetworkManager** 
 1) request, 
 2) fetching 
 3) parsing 


### NetworkManager
The  **NetworkManager**: is responsible for handling all network related calls like GET, POST etc

### UnitTests

This module consists XCTTest classes for testing. 
- **FlickerNetworkTests**: This class is responsible for validating image fetched
