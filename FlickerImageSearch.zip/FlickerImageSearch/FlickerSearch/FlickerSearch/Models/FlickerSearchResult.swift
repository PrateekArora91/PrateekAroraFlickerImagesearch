//
//  FlickerSearchResult.swift
//  FlickerSearch
//
//  Created by Prateek Arora on 17/07/20.
//  Copyright © 2020 Prateek Arora . All rights reserved.
//

import UIKit

struct FlickerSearchResult: Codable {
    let statistics: String?
    let photos: Photos?
}
