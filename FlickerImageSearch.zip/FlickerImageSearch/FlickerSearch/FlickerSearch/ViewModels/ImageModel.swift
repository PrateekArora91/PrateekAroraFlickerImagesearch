//
//  ImageModel.swift
//  FlickerSearch
//
//  Created by Prateek Arora on 17/07/20.
//  Copyright © 2020 Prateek Arora . All rights reserved.
//

import UIKit
struct ImageModel {

    let imageURL: String
    init(withPhotos photo: FlickerPhoto) {
        imageURL = photo.imageURL
    }
}
