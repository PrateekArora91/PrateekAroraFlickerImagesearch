//
//  DataCaching.swift
//  FlickerSearch
//
//  Created by Prateek Arora on 17/07/20.
//  Copyright © 2020 Prateek Arora . All rights reserved.
//

import UIKit

class DataCaching: NSObject {

    static let shared = DataCaching()
    private(set) var caching: NSCache<AnyObject, AnyObject> = NSCache()
    
    func getImageFromCache(key: String) -> UIImage? {
        if (self.caching.object(forKey: key as AnyObject) != nil) {
            return self.caching.object(forKey: key as AnyObject) as? UIImage
        } else {
            return nil
        }
    }
    
    func saveImageToCache(key: String, image: UIImage) {
        self.caching.setObject(image, forKey: key as AnyObject)
    }
    
}
