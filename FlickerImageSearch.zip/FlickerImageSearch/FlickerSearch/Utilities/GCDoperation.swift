//
//  Utility.swift
//  FlickerSearch
//
//  Created by Prateek Arora on 17/07/20.
//  Copyright © 2020 Prateek Arora . All rights reserved.
//

import UIKit

class GCDoperation {
  
    static func runonMainThread(closure: @escaping () -> Void) {
        DispatchQueue.main.async {
            closure()
        }
    }
    static func runAsync(closure: @escaping () -> Void) {
          DispatchQueue.global(qos: .userInitiated).async {
              closure()
          }
      }
      
}
