//
//  FlickerRequestConfig.swift
//  FlickerSearch
//
//  Created by Prateek Arora on 17/07/20.
//  Copyright © 2020 Prateek Arora . All rights reserved.
//

import UIKit

enum FlickerRequestConfig {
    
    case searchRequest(String, Int)
    
    var value: Request? {
        
        switch self {
            
        case .searchRequest(let searchText, let pageNo):
            let urlString = String(format: FlickerConstants.searchURL, searchText, pageNo)
            let reqConfig = Request.init(requestMethod: .get, urlString: urlString)
            return reqConfig
        }
    }
}
